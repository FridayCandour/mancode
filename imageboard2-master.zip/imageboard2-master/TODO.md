# TODO

- Better solution for replies (Don't buffer up all)
- Better solution for index (Keep file of latest threadID's instead of iterating
  entire dir)
- boards
- images
- IP-based IDs ([README](README.md))
- Browser notifications
- Atom / RSS
- Pinned threads
- Images
